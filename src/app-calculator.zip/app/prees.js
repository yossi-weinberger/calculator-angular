document.addEventListener('keypress', function(event) {
    if (event.key === 49) {
        func(1);
    } else if (event.key === 50) {
        func(2);
    } else if (event.key === '51') {
        func(3);
    }
});
